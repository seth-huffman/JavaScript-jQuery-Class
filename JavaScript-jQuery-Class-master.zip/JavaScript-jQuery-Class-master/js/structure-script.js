$(document).ready(function(e) {
	$("#hide").click(function(e) {
		$("#div1").hide();
	});
	$("#show").click(function(e) {
		$("#div1").show();
	});
	$("#remove").click(function(e) {
		$("#div2").hide();
	});
	$("#add").click(function(e) {
		$("#div2").show();
	});
});